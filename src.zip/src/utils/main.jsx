import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { store } from "../app/store"; // Hapus satu titik (tadinya ../ sekarang ./)
import { injectStore } from "../api/axiosInstance"; // Hapus satu titik (tadinya ../ sekarang ./)
import App from "App.jsx"; // Pastikan ini benar jika App.jsx ada di folder src juga
import "../styles/global.css"; // Sesuaikan jika folder styles ada di dalam src

injectStore(store);

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </StrictMode>
);